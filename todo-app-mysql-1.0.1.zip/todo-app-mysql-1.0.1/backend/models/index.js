const UserModel = require('./UserModel');
const TodoModel = require('./TodoModel');

module.exports = { UserModel, TodoModel };

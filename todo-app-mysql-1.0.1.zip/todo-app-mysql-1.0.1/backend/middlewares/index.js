const authenticateToken = require('./auth');

module.exports = { authenticateToken };

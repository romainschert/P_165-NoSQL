<script setup lang="ts">
import ProfileLogin from '@/components/ProfileLogin.vue';
</script>

<template>
  <ProfileLogin />
</template>
